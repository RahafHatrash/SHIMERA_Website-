<?php 
 
error_reporting(E_ALL); 
ini_set('display_errors', 1); 
 
// Establish database connection 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "PCweb"; 
 
// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
 
// Check connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
} 
// Check if form is submitted 
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    // Retrieve form data 
    $name = $_POST['name']; 
    $email = $_POST['email']; 
    $phone_number = $_POST['phone_number']; 
    $password = $_POST['password']; 
    // Check email format 
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
        echo "<script>alert('Error: Invalid email format, Ex: Example@mail.com '); 
        window.location.href = 'signup.php';</script>"; 
        exit(); // Stop further execution if email format is invalid 
    } 
    // Check password strength 
    if (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()-_+=])[a-zA-Z\d!@#$%^&*()-_+=]{8,}$/", $password)) { 
        echo "<script>alert('Error: Password must be at least 8 characters long and contain at least one special character, one uppercase letter, and one number.'); 
        window.location.href = 'signup.php';</script>"; 
        exit(); // Stop further execution if password doesn't meet the criteria 
    } 
    // Check if the phone number already exists in the database 
    $check_phone_query = "SELECT * FROM Users WHERE phone_number = ?"; 
    $check_phone_stmt = $conn->prepare($check_phone_query); 
    $check_phone_stmt->bind_param("s", $phone_number); 
    $check_phone_stmt->execute(); 
    $phone_result = $check_phone_stmt->get_result(); 
    // Check if the email already exists in the database 
    $check_email_query = "SELECT * FROM Users WHERE email = ?"; 
    $check_email_stmt = $conn->prepare($check_email_query); 
    $check_email_stmt->bind_param("s", $email); 
    $check_email_stmt->execute(); 
    $email_result = $check_email_stmt->get_result(); 
    if ($phone_result->num_rows > 0) { 
        echo "<script> 
                var confirmation = confirm('Error: This phone number is already registered. Would you like to go to the login page?'); 
                if (confirmation) { 
                    window.location.href = '2login.php';      } else { 
                    window.location.href = 'signup.php';     } 
              </script>"; 
    } elseif ($email_result->num_rows > 0) { 
        echo "<script>alert('Error: This email address is already registered.');</script>"; 
    } else { 
        // Generate a unique salt for each user 
        $salt = generateSalt(); 
 
        // Combine salt with the password 
        $saltedPassword = $salt . $password; 
 
        // Hash the salted password 
        $hashedPassword = hash('sha256', $saltedPassword); 
 
        // SQL query to insert data into the Users table 
        $sql = "INSERT INTO Users (name, email, phone_number, password, salt) VALUES (?, ?, ?, ?, ?)"; 
        $stmt = $conn->prepare($sql); 
        $stmt->bind_param("sssss", $name, $email, $phone_number, $hashedPassword, $salt); 
        $stmt->execute(); 
 
        if ($stmt->affected_rows > 0) { 
            echo "<script>alert('Registration successful.');</script>"; 
            echo "<script>window.location.href = 'index.php';</script>"; 
            exit(); // Stop further execution after redirection 
        } else { 
            echo "Error: " . $stmt->error; 
        } 
    } 
} 
 
// Close connection 
$conn->close(); 
 
/** 
 * Function to generate a random salt. 
 * 
 * @return string 
 */ 
function generateSalt() 
{ 
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
    $salt = ''; 
    for ($i = 0; $i < 16; $i++) { 
        $salt .= $characters[rand(0, strlen($characters) - 1)]; 
    } 
    return $salt; 
} 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>

    <link rel="stylesheet" type="text/css" href="style.css">

<style>

.container1 ,h2{
  text-align:center;
}

h2{
    position:relative;
top:15px;
        left:190px;

}

.in1{
        width:14%;
        position:relative;
        top:35px;
        left:63px;
     

      
    }
    a{
        position: relative;
        left:10px;
    }
    .pos{
        position: relative;
        top:30px;
    }
    .in1:hover{
      background:black;
      color:white;
    }
    a[ href="login.php"]{
        color:black;
        font-size:10px;
        position:relative;
        top:-10px;
        left:-50px;
    }
     
    input[type="text"], input[type="password"]{
        position: relative;
        top: 10px;
        width:25%;
        radius:2px;
    }
</style>
</head>
<body>

<img src="component/2.png" class="backg1">
  <br><br>
  <img src="component/2.png" class="backg1s2" style="transform: scaleX(-1); right: 700px; top: 300px;">

<div class="container1">
    <div class="pos">
<h2>Sign Up</h2>
<form name="userForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
<input type="text" name="name" placeholder="Your name..." required><br><br>
<input type="text" name="email" placeholder="Your Email..." required><br><br>
    <input type="text" name="phone_number" placeholder="Your phone number..." required><br><br>
    <input type="password" name="password" placeholder="Your Password..." required><br><br>

    <button class="in1" type="submit"  name="Signup">Signup</button>

    <a   class="link" href="2login.php"> <em> have account? Login page</em> </a> 
</form>
</div>
</div>
</body>
</html>
