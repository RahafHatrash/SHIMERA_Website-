<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Products Page</title>
  <link rel="stylesheet" href="style.css">

  <style>

.in1{
        width:7%;
        position:relative;
        left:550px;
        top:90px;

    }
    .in1:hover{
      background:black;
      color:white;
    }
    .tx1{

      color:black;
      position: relative;
      top:-0px;
      left:-10px;
      text-decoration: none;
    }
    .in2{
      width:15%;
        position:relative;
        left:550px;
        top:90px;

    }
    .enlarged { 
      position: absolute; 
      top: 50%; 
      left: 50%; 
      transform: translate(-50%, -50%) scale(1.5); 
      z-index: 9999; 
      border: 2px solid #000;
    }
  </style>
  --------------------------------------------------
  <script>
    // Function to add the 'enlarged' class to the image on mouseover
    function enlargeImage(element) {
      element.classList.add("enlarged");
    }

    // Function to remove the 'enlarged' class from the image on mouseout
    function resetImage(element) {
      element.classList.remove("enlarged");
    }
  </script>
  ---------------------------------------------------------------
</head>
<body>
<nav class="navbar">
    <ul>
    <li><a href="index.php">Home Page</a></li>
            <li><a href="2product.php">Products</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Contact Us</a></li>
            <li><a href="profile.php">My Profile</a></li>

        </ul>
  </nav>


  <img src="component/2.png" class="backg1">
  <br><br>
  <img src="component/2.png" class="backg1s2" style="transform: scaleX(-1); right: 700px; top: 300px;">

  <div>

<form action="ProductDetails.php" method="get">
      <input class="in2" type="text" name="productName" placeholder="Search for products..." required>
    <button class="in1" type="submit">Search</button>
</form>
    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "PCweb";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to fetch all products including the URL details
  // SQL query to fetch all products
$stmt = $conn->prepare("SELECT name, description, price, image_url, urlLinkDetails FROM products");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
      echo '<div class="container1">';
      echo '<div class="images"><img src="' . htmlspecialchars($row['image_url']) . '" onmouseover="enlargeImage(this)" onmouseout="resetImage(this)" /></div>';
      echo '<div class="line"></div>';
      echo '<div class="product">';
      echo '<p> Name of product: ' . htmlspecialchars($row['name']) . '<br></p>';
      echo ' <br><p class="titleProduct"><br> <br>' . htmlspecialchars($row['description']) . '</p><br>';
      echo '<p class="Price">' . number_format($row['price'], 2) . ' SAR</p>';
      echo '</div>';
      echo '</div><br>';
  }
} else {
  echo "No products found.";
}

    $stmt->close();
    $conn->close();
    ?>
  </div>


 
</body>
</html>
