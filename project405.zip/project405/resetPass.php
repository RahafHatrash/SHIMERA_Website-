<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "PCweb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];


 // Check password strength 
    if (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()-_+=])[a-zA-Z\d!@#$%^&*()-_+=]{8,}$/", $password)) { 
        echo "<script>alert('Error: Password must be at least 8 characters long and contain at least one special character, one uppercase letter, and one number.'); 
        window.location.href = 'resetPass.php';</script>"; 
        exit(); // Stop further execution if password doesn't meet the criteria 
    } 
 
    // Check if the email exists in the database
    $sql = "SELECT * FROM Users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result(); // Get the result set

    if ($result->num_rows > 0) {
        // Account found

        // Generate a unique salt for each user
        $salt = generateSalt();

        // Combine salt with the password
        $saltedPassword = $salt . $password;

        // Hash the salted password
        $hashedPassword = hash('sha256', $saltedPassword);

        // Update the password in the database
        $sql = "UPDATE Users SET password = ?, salt = ? WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $hashedPassword, $salt, $email);
        $stmt->execute();

        echo '<script>
        if(confirm("Password Reset Was successful. Click OK to proceed to login.")){
            window.location.href="2login.php";
        } else {
            window.location.href="resetPass.php";
        }
        </script>';
    } else {
        // Account not found
        echo '<script> alert("Email Does not Exist!."); 
        window.location.href="resetPass.php"; 
        </script>';
    }
}

$conn->close();

/**
 * Function to generate a random salt.
 *
 * @return string
 */
function generateSalt()
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $salt = '';
    for ($i = 0; $i < 16; $i++) {
        $salt .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $salt;
}
?>


<!DOCTYPE html>


<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
    <title>Login</title>


  <style>


.container1 ,h2{
  text-align:center;
}

h2{
    position:relative;
top:15px;
        left:190px;

}

.in1{
        width:30%;
        position:relative;
        top:30px;
        left:0px;
     

      
    }
    .in1:hover{
      background:black;
      color:white;
    }
  
    .pos{
        position: relative;
        top:30px;
    }
    
    input[type="text"], input[type="password"]{
        position: relative;
        top: 10px;
        width:25%;
        radius:2px;
    }
   
  </style>

</head>
<body>

<img src="component/2.png" class="backg1">
  <br><br>
  <img src="component/2.png" class="backg1s2" style="transform: scaleX(-1); right: 700px; top: 300px;">

<div class="container1">
    <div class="pos">
<h2>Reset Password</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<input type="text" name="email" placeholder="Your Email..." ><br><br>
    <input type="password" name="password" placeholder="Your Password..." required><br><br>

    <button class="in1" type="submit"  name="login">Reset Password</button>


</form>
</div>
</div>
<?php if(isset($login_error)) echo "<p>$login_error</p>"; ?>

</body>
</html>
