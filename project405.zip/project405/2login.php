<?php 
 
error_reporting(E_ALL); 
ini_set('display_errors', 1); 
 
// Establish database connection 
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "PCweb"; 
 
// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname); 
 
// Check connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
} 
 
// Check if form is submitted 
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    if(isset($_POST['login'])) { 
        // Retrieve form data 
        $email = $_POST['email']; 
        $password = $_POST['password']; 
 
        // Check if the user exists with the given email 
        $sql_check_user = "SELECT * FROM Users WHERE email = '$email'"; 
        $result_check_user = $conn->query($sql_check_user); 
 
        if ($result_check_user->num_rows > 0) { 
            // User exists, check password 
            $row = $result_check_user->fetch_assoc(); 
            $salt = $row['salt']; 
            $salted_password = $salt . $password; 
            $hashed_password = hash('sha256', $salted_password); 
 
            if ($row['password'] == $hashed_password) { 
                // Password is correct, redirect to index.php 
                header("Location: index.php"); 
                exit(); // Stop further execution 
            } else { 
                // Incorrect password, display error message 
                echo "<script>alert('Incorrect password. Please try again.');</script>"; 
            } 
        } else { 
            // User does not exist, display sign-up page link 
            echo "<script>alert('No account found for this email.');</script>"; 
        } 
    } 
    elseif(isset($_POST['reset'])) { 
        // Handle password reset request 
        // Redirect to reset password page 
        header("Location: reset_password.html"); 
        exit(); // Stop further execution 
    } 
} 
 
// Close connection 
$conn->close(); 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">

  <style>


.container1 ,h2{
  text-align:center;
}

h2{
    position:relative;
top:15px;
        left:190px;

}

.in1{
        width:14%;
        position:relative;
        top:50px;
        left:120px;
     

                <?php if (!empty($errors)): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endforeach; ?>
            <?php endif; ?>
      
    }
    .in1:hover{
      background:black;
      color:white;
    }
    a{
        position: relative;
        left:10px;
    }
    .pos{
        position: relative;
        top:30px;
    }
    
    input[type="text"], input[type="password"]{
        position: relative;
        top: 10px;
        width:25%;
        radius:2px;
    }
    a[ href='signup.php']{
        color:black;
        font-size:10px;
        position:relative;
        top:100px;
        left:-110px;
    }
   
  </style>
</head>
<body>

  <img src="component/2.png" class="backg1">
  <br><br>
  <img src="component/2.png" class="backg1s2" style="transform: scaleX(-1); right: 700px; top: 300px;">


  <div class="container1">
    <div class="pos">
<h2>Login</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <input type="text" name="email" placeholder="Your Email..." required><br><br>
    <input type="password" name="password" placeholder="Your Password..." required><br><br>

    <button class="in1" type="submit"  name="login">Login</button>

 
    <a href="resetPass.php">Forgot Password?</a>
    <a  class="link" href='signup.php'>Don't have an account? Sign Up</a>
</form>

<!-- Display login error message -->
<?php if(isset($login_error)) echo "<p>$login_error</p>"; ?>

</body>
</html>
