 <?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection settings
$servername = "localhost";
$username = "root"; // Your database username
$password = "";     // Your database password
$dbname = "PCweb";  // Your database name

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['email']) ? $conn->real_escape_string($_POST['email']) : '';

    // Email Format Check
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format');</script>";
        echo "<script>window.location.href='OrderDetailsPage.php';</script>";
        exit;
    }
    
    // Data Type Check for zip code (must be numeric)
    $zipCode = isset($_POST['zipCode']) ? $_POST['zipCode'] : '';
    if (!is_numeric($zipCode)) {
        echo "<script>alert('Zip code must be a numeric value');</script>";
        echo "<script>window.location.href='OrderDetailsPage.php';</script>";
        exit;
    }
    
    // Range Check for phone number (must be 10 digits)
    $phoneNumber = isset($_POST['phoneNumber']) ? $_POST['phoneNumber'] : '';
    if (strlen($phoneNumber) !== 10 || !is_numeric($phoneNumber)) {
        echo "<script>alert('Phone number must be 10 digits');</script>";
        echo "<script>window.location.href='OrderDetailsPage.php';</script>";
        exit;
    }
    
    // Required Field Validation for other fields
    $requiredFields = ['name', 'email', 'phoneNumber', 'country', 'state', 'city', 'house_Address'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            echo "<script>alert('" . ucfirst(str_replace('_', ' ', $field)) . " is required');</script>";
            echo "<script>window.location.href='OrderDetailsPage.php';</script>";
            exit;
        }
    }

    // Check if email already exists in the database 
    $checkEmailSql = "SELECT * FROM users WHERE email = ?"; 
    $checkEmailStmt = $conn->prepare($checkEmailSql);
    $checkEmailStmt->bind_param("s", $email);
    $checkEmailStmt->execute();
    $checkEmailResult = $checkEmailStmt->get_result(); 

    if ($checkEmailResult->num_rows > 0) { 
        // Update the existing record with the new information 
        $updateSql = "UPDATE users SET name = ?, country = ?, state = ?, city = ?, street_address = ?, zip_code = ?, phone_number = ? WHERE email = ?"; 
        $updateStmt = $conn->prepare($updateSql); 
 
        // Get user input 
        $name = isset($_POST['name']) ? $conn->real_escape_string($_POST['name']) : ''; 
        $country = isset($_POST['country']) ? $conn->real_escape_string($_POST['country']) : ''; 
        $state = isset($_POST['state']) ? $conn->real_escape_string($_POST['state']) : ''; 
        $city = isset($_POST['city']) ? $conn->real_escape_string($_POST['city']) : ''; 
        $streetAddress = isset($_POST['house_Address']) ? $conn->real_escape_string($_POST['house_Address']) : ''; 
        $zipCode = isset($_POST['zipCode']) ? $conn->real_escape_string($_POST['zipCode']) : ''; 
        $phoneNumber = isset($_POST['phoneNumber']) ? $conn->real_escape_string($_POST['phoneNumber']) : ''; 
 
        $updateStmt->bind_param("ssssssss", $name, $country, $state, $city, $streetAddress, $zipCode, $phoneNumber, $email); 
 
        if ($updateStmt->execute()) { 
            echo "<script>alert('User information updated successfully.');"; 
            echo "window.location.href='ConfirmationPage.php';</script>"; 
        } else { 
            echo "<script>alert('Error updating user information: " . $updateStmt->error . "');</script>"; 
            // Redirect back to OrderDetailsPage.php 
            echo "window.location.href='OrderDetailsPage.php';</script>";

        } 
 
        $updateStmt->close(); 
    } else {
        // Insert the new user information
        $name = isset($_POST['name']) ? $conn->real_escape_string($_POST['name']) : ''; 
        $country = isset($_POST['country']) ? $conn->real_escape_string($_POST['country']) : ''; 
        $state = isset($_POST['state']) ? $conn->real_escape_string($_POST['state']) : ''; 
        $city = isset($_POST['city']) ? $conn->real_escape_string($_POST['city']) : ''; 
        $streetAddress = isset($_POST['house_Address']) ? $conn->real_escape_string($_POST['house_Address']) : ''; 
        $zipCode = isset($_POST['zipCode']) ? $conn->real_escape_string($_POST['zipCode']) : ''; 
        $phoneNumber = isset($_POST['phoneNumber']) ? $conn->real_escape_string($_POST['phoneNumber']) : ''; 

        $insertSql = "INSERT INTO users (name, country, state, city, street_address, zip_code, phone_number, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"; 
        $insertStmt = $conn->prepare($insertSql); 
        $insertStmt->bind_param("ssssssss", $name, $country, $state, $city, $streetAddress, $zipCode, $phoneNumber, $email); 
        
        if ($insertStmt->execute()) { 
            echo "<script>alert('User added successfully.');"; 
            echo "window.location.href='ConfirmationPage.php';</script>"; 
        } else { 
            echo "<script>alert('Error adding user: " . $insertStmt->error . "');</script>"; 
            // Redirect back to OrderDetailsPage.php 
            echo "window.location.href='OrderDetailsPage.php';</script>"; 
        } 
 
        $insertStmt->close(); 
    } 
 
    $checkEmailStmt->close(); 
    $conn->close(); 
} 
?>

<!DOCTYPE html>
<html>

<head>
    <title>Order page</title>
    <link rel="stylesheet" href="style.css">
    <style>

        .navbar {
  width: 100%;
  background-color: transparent; /* Ensure navigation blends with the background */
  display: flex;
  justify-content: space-between;
  align-items: center;
  text-align:center;
  padding: 20px 160px; /* Adjust padding as needed */
}

.navbar ul {
  list-style: none;
  padding: 0;
}

.navbar ul li {
  display: inline;
  margin-right: 20px; /* Space between nav items */
}

.navbar ul li a {
  color: white;
  text-decoration: none;
  font-size: 16px;
}
.navbar31{
    text-align:center;
    position: relative;
    left:100px;
}

label{
    color:black;
}

.error-messages {
            text-align: center;
            margin-top: -100px; /* Adjust spacing as needed */
        }

.error-messages p {
            color: red;
            font-size: 14px;
            margin-bottom: 5px; /* Adjust spacing between messages */
        }
        
    </style>
      
   

   <script> 
    window.onload = function() { 
        // Function to handle focus event 
        function handleFocus(element) { 
            element.setAttribute("placeholder", element.getAttribute("hint-text")); 
        } 
 
        // Function to handle blur event 
        function handleBlur(element) { 
            element.setAttribute("placeholder", ""); 
        } 
 
        // Function to handle keypress event 
        function handleKeyPress(event) { 
            var charCode = event.which || event.keyCode; 
            var charStr = String.fromCharCode(charCode); 
 
            // Check if the entered character is a number 
            if (!isNaN(charStr)) { 
                alert("Please enter only letters."); 
                event.preventDefault(); 
            } 
             
        } 
 
        // Get the email and phone number input elements 
        var emailInput = document.querySelector("input[name='email']"); 
        var phoneInput = document.querySelector("input[name='phoneNumber']"); 
        var NameInput = document.querySelector("input[name='name']"); 
        
 
        // Attach focus and blur event listeners to email input 
        emailInput.addEventListener("focus", function() { 
            handleFocus(this); 
        }); 
 
        emailInput.addEventListener("blur", function() { 
            handleBlur(this); 
        }); 
 
        // Attach focus and blur event listeners to phone number input 
        phoneInput.addEventListener("focus", function() { 
            handleFocus(this); 
        }); 
 
        phoneInput.addEventListener("blur", function() { 
            handleBlur(this); 
        }); 
 
        // Attach keypress event listener to  name input 
        NameInput.addEventListener("keypress", function(event) { 
            handleKeyPress(event); 
        }); 
    }; 
</script>
</head>

<body>

    <img src="component/2.png" width="" height="" class="backg1">
    <br><br>
    <img src="component/2.png" width="" height="" class="backg1s2"
        style="transform: scaleX(-1);    right: 700px; top: 300px;">


    <div class="OrderPage">
    
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <div class="containerOrder">
                <h2>Conatct</h2>

                <label> Email</label><span class="spanStar">*</span><br>
                <input class="AdjusitBox" name="email" type="text" size="25" hint-text="Ex.example@gmail.com" required> <br>
                <input class="CheckEdit" name="newsAndOffers" type="checkbox" value="EmailNews">
                <label>Email me with news and offers</label>


                <h2>Shipping Address</h2>

                <label>Name</label><span class="spanStar">*</span><br>
                <input class="AdjusitBox" name="name" type="text" size="20" >
                <br>
                
            
                <br>
                <label>Country/Region</label><span class="spanStar">*</span><br>
                <select class="AdjusitBox" name="country" >
                    <option>Australia</option>
                    <option>Belgium</option>
                    <option>canada</option>
                    <option>Estonia</option>
                    <option>Finland</option>
                    <option>Germany</option>
                    <option>Hong Kong</option>
                    <option>Italy</option>
                    <option>Kuwait</option>
                    <option>Mexico</option>
                    <option>New Zealand</option>
                    <option>Poland</option>
                    <option Selected>Saudi Arabia</option>
                    <option>Spain</option>
                    <option>United Arab Emirates</option>
                </select>
                <br>
                <label>State</label><span class="spanStar">*</span><br>
                <select class="AdjusitBox" name="state" >
                    <option Selected>Makkah</option>
                    <option>Bahah</option>
                    <option>Jizan</option>
                    <option>Ha'il</option>
                    <option>Madinah</option>
                    <option>Tabuk</option>
                </select>
                <br>
                <label>Town/City</label><span class="spanStar">*</span><br>
                <input class="AdjusitBox" name="city" type="text" size="25"  >
                <br>
                <label>Street Address</label><span class="spanStar">*</span><br>
                <input class="AdjusitBox" name="house Address" type="text" size="25"   >
                <br>
                <label>Zip Code</label><span class="spanStar"></span><br>
                <input class="AdjusitBox" name="zipCode" type="text" size="25" >
                <br>
                <label>Phone Number</label><span class="spanStar">*</span><br>
                <input class="AdjusitBox" name="phoneNumber" type="tel" size="25" hint-text="Ex.05*********"  >
                <br>
                <input class="CheckEdit" name="newsAndOffers" type="checkbox" value="PhoneNews">
                <label>Text me with news and offers</label>


                <h2>Your Order</h2>
                <table>
                    <thead>
                        <tr>
                            <th class="thOrder"> Product</th>
                            <th class="thOrder"> Quantity</th>
                            <th class="thOrder">Category</th>
                            <th class="thOrder"> Unit Price</th>
                            <th class="thOrder"> Total Price</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td class="tdOrder">ThinkPad X1 Carbon Gen 11 (14, Intel)</td>
                            <td class="tdOrder"> 1</td>
                            <td class="tdOrder"> Tablets</td>
                            <td class="tdOrder"> SAR5000</td>
                            <td class="tdOrder"> SAR5000</td>
                        </tr>

                        <tr>
                            <td class="tdOrder">Dell -22- Monitor – SE2222H- 54.5cm (21.5″)</td>
                            <td class="tdOrder"> 2</td>
                            <td class="tdOrder"> Monitor</td>
                            <td class="tdOrder"> SAR200</td>
                            <td class="tdOrder"> SAR400</td>
                        </tr>

                        <tr>
                            <td class="tdOrder">Glorious Extended Gaming Mouse Pad – 11″x36″- White Edition</td>
                            <td class="tdOrder"> 3</td>
                            <td class="tdOrder"> Accessories</td>
                            <td class="tdOrder">SAR50</td>
                            <td class="tdOrder"> SAR150</td>
                        </tr>

                    <tfoot>
                        <tr>
                            <th class="thOrder" colspan="4">Total</th>
                            <td class="tdOrder"> SAR5500</td>
                        </tr>
                    </tfoot>
                </table>

                <h2> Payment Method </h2>

                <br>
                <input class="CheckEdit" name="payment" type="radio" value="credit card" >
                <label>Credit Card</label><br>
                <input class="CheckEdit" name="payment" type="radio" value="paypal" >
                <label>PayPal</label><br>
                <input class="CheckEdit" name="payment" type="radio" value="cash" ><label>Cash</label><br>

                <button class="orderButton" type="submit" onclick="return confirm('Are you sure you want to place the order?')">Place Order</button>
                <button class="orderButton" type="reset" onclick="return confirm('Are you sure you want to cancel the order?') ? window.location.href = 'index.php' : false">Cancel Order</button>
            
        </form>

              

            </div>
        </form>
    </div>
</body>

</html>  