<!DOCTYPE html>
<html>
<head>
    <title>HomePage</title>
    <link rel="stylesheet" href="style.css">

    <style>
        .mesg {
            color: white;
            font-family: "Courier New", monospace;
            width: 100%;
            font-size: 15px;
            top: 50px;
            position: relative;
            left: -40px;
        }
        
        .div12 {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: -40px;
            position: relative;
            left: 40px;
          
            
        }

        input[type="email"] {
            padding: 10px;
            width: 300px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            position: relative;
            left: -30px;
            top:130px;
        }
        

      
        .error {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }

        .txt{
            
            position:relative;
            top:90px;
            background: white;
            text-align: center; 
            color: black;
            font-family: "Courier New", monospace;
            font-size: 15;
        }
        .div13{
         position: relative;
         top:90px;
         left:600px;
        width:20%;

        }
    </style>
</head>
<body>
<nav class="navbar">
    <ul>
    <li><a href="index.php">Home Page</a></li>
            <li><a href="2product.php">Products</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Contact Us</a></li>
            <li><a href="profile.php">My Profile</a></li>

        </ul>
  </nav>

  <img src="component/2.png" class="backg1">
  <br><br>
  <img src="component/2.png" class="backg1s2" style="transform: scaleX(-1); right: 700px; top: 300px;">

    <h2>Shipping Address</h2>
    <div class="div12">
        <form method="post" action="">
            <h6 class="mesg">Enter your email to display your address:</h6>
            <input type="email" name="email"><br><br>
            <button  type="submit" value="Submit">Submit</button>
        
        </form>


    </div>

    <div class="div13">
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>">
        <button type="submit" name="delete_address">Delete Address</button>
        <button type="submit" name="update_address"> <a href="UpdateAddress.php">Update Address</a></button>
    </form>
</div>


    <?php
    // Error reporting for debugging purposes
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "PCweb";

    // Create a MySQLi connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    // Check if the delete button is clicked
if (isset($_POST['delete_address'])) {
    $email = isset($_POST['email']) ? $_POST['email'] : '';

    // Delete the user's address
    $stmt = $conn->prepare("DELETE FROM Users WHERE email = ?");
    $stmt->bind_param('s', $email);
    if ($stmt->execute()) {
        echo '<div class="txt">Address deleted successfully.</div>';
    } else {
        echo '<div class="txt">Error deleting address.</div>';
    }
    $stmt->close();
}



    // Check if email exists in the Users table
    if (isset($_POST['email'])) {
        $email = $_POST['email'];

        $stmt = $conn->prepare("SELECT * FROM Users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Display the retrieved user data
            echo '  <br> <div class="txt" >' ;
            echo  "<br>"."Email: " . $user['email'] . "<br>". "<br>";
            echo "Phone Number: " . $user['phone_number'] . "<br>". "<br>";
            echo "Zip Code: " . $user['zip_code'] . "<br>". "<br>";
            echo "Country: " . $user['country'] . "<br>". "<br>";
            echo "State: " . $user['state'] . "<br>". "<br>";
            echo "City: " . $user['city'] . "<br>". "<br>";
            echo "Street Address: " . $user['street_address'] . "<br>". "<br>";
            echo "</div>";
        } else {
            echo ' <div class="txt"> <br>  No address assigned for this email <br>  <br></div>';
        }
        $stmt->close();
    }
    $conn->close();
    ?>
</body>
</html>
