<!DOCTYPE html>
<html>

<head>
    <title>HomePage </title>
    <link rel="stylesheet" href="style.css">
    <style>.in1{
        width:20%;
        position:relative;
        top:200px;
        left:600px;
     

                <?php if (!empty($errors)): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endforeach; ?>
            <?php endif; ?>
      
    }
    .in1:hover{
      background:black;
      color:white;
    }</style>
</head>

<body>
<nav class="navbar">
    <ul>
    <li><a href="index.php">Home Page</a></li>
            <li><a href="2product.php">Products</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Contact Us</a></li>
            <li><a href="profile.php">My Profile</a></li>

        </ul>
  </nav>
    

    <div>
        <img src="component/2.png" width="" height="" class="backg1">
        <img src="component/3.png" width="" height="" class="backg2">

    </div>

    
    <button class="in1" type="submit"  name="login"><a href="Address.php"> My Address </a></button>
    <br>
    <br><br>
    <br>

    <button class="in1" type="submit"  name="login"> My Order </button>
    <br><br>
    <br>
    <br>
    <button class="in1" type="submit"  name="login">Home Page </button>



    <footer class="footer">

<ul>
<div style="text-align:center;">
    <li><a href="https://maps.app.goo.gl/ynVmfsHXWSY17oEw5?g_st=it">Location</a></li><br>
    <li><a href="mailto:r.a.hatrash2001@gmail.com">For contact</a></li>
    </div>
    <br>
    <li>Our Branches : </li> <br>
    <br>
 

    <li> 3789 - Al Fayha Dist. JEDDAH 2902 - 22241 <br> Kingdom of Saudi Arabia</li> <br>
    <li> 8885 - Al Hamra Dist. MAKKAH 2902 - 22241 <br> Kingdom of Saudi Arabia</li><br>
 

</ul>
</footer>

</body>

</html>