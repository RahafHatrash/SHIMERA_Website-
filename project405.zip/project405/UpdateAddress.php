<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "PCweb";

    // Create a MySQLi connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to check if email exists
    $checkEmailSql = "SELECT * FROM users WHERE email = ?";
    $checkStmt = $conn->prepare($checkEmailSql);
    $checkStmt->bind_param("s", $_POST['email']);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // Email exists, proceed with update
        $updates = array();
        foreach ($_POST as $key => $value) {
            if ($key != "submit" && !empty($value)) {
                $updates[] = "$key = '" . $conn->real_escape_string($value) . "'";
            }
        }
        
        $updateSql = "UPDATE users SET " . implode(", ", $updates) . " WHERE email = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("s", $_POST['email']);

        if ($updateStmt->execute()) {
            echo "<script>alert('User information updated successfully.');</script>";
        } else {
            echo "<script>alert('Error updating record: " . $updateStmt->error . "');</script>";
        }

        $updateStmt->close();
    } else {
        // Email does not exist, provide alert message
        echo "<script>alert('No account found with that email. Please check the email or register a new account.');</script>";
    }

    // Close statement and connection
    $checkStmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" href="style.css">
    <title>Order page</title>
    <link rel="stylesheet" href="style.css">


<!DOCTYPE html>
<html>

<head>
    <title>Order page</title>
    <link rel="stylesheet" href="style.css">
    <style>

        .navbar {
  width: 100%;
  background-color: transparent; /* Ensure navigation blends with the background */
  display: flex;
  justify-content: space-between;
  align-items: center;
  text-align:center;
  padding: 20px 160px; /* Adjust padding as needed */
}

.navbar ul {
  list-style: none;
  padding: 0;
}

.navbar ul li {
  display: inline;
  margin-right: 20px; /* Space between nav items */
}

.navbar ul li a {
  color: white;
  text-decoration: none;
  font-size: 16px;
}
.navbar31{
    text-align:center;
    position: relative;
    left:100px;
}

label{
    color:black;
}

.error-messages {
            text-align: center;
            margin-top: -100px; 
        }

.error-messages p {
            color: red;
            font-size: 14px;
            margin-bottom: 5px; /* Adjust spacing between messages */
        }

        .containerOrder {
    padding: 5px; 
    height: 900px; 
}

.orderButton{
position: relative;
top:30px;
width:50%;

}


    </style>
 
</head>

<body>
<nav class="navbar">
    <ul>
    <li><a href="index.php">Home Page</a></li>
            <li><a href="2product.php">Products</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Contact Us</a></li>
  
        </ul>
  </nav>
  
    <img src="component/2.png" width="" height="" class="backg1">
    <br><br>
    <img src="component/2.png" width="" height="" class="backg1s2"
    style="transform: scaleX(-1);    right: 700px; top: 300px;">


    <div class="OrderPage">
    
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <div class="containerOrder">
        <h2>Update user information</h2>

        <label>Email</label><br>
        <input class="AdjusitBox" name="email" type="text" size="25" placeholder="example@gmail.com"><br>

        <label>Name</label><span class="spanStar"></span><br>
        <input class="AdjusitBox" name="name" type="text" size="20" placeholder="Enter your first name" required><br>

 
            <!-- Options for countries -->
        </select><br>

        <label>State</label><span class="spanStar"></span><br>
                <select class="AdjusitBox" name="state" >
                    <option Selected>Makkah</option>
                    <option>Bahah</option>
                    <option>Jizan</option>
                    <option>Ha'il</option>
                    <option>Madinah</option>
                    <option>Tabuk</option>
                </select>
                <br>
        <label>Country/Region</label><span class="spanStar"></span><br>
        <select class="AdjusitBox" name="country" required>
                    <option>Australia</option>
                    <option>Belgium</option>
                    <option>canada</option>
                    <option>Estonia</option>
                    <option>Finland</option>
                    <option>Germany</option>
                    <option>Hong Kong</option>
                    <option>Italy</option>
                    <option>Kuwait</option>
                    <option>Mexico</option>
                    <option>New Zealand</option>
                    <option>Poland</option>
                    <option Selected>Saudi Arabia</option>
                    <option>Spain</option>
                    <option>United Arab Emirates</option>
                </select>   
                <br>

        <label>Town/City</label><span class="spanStar"></span><br>
        <input class="AdjusitBox" name="city" type="text" size="25" placeholder="Enter your town/city"><br>

        <label>Street Address</label><span class="spanStar"></span><br>
        <input class="AdjusitBox" name="street_address" type="text" size="25" placeholder="Enter your street address"><br>

        <label>Zip Code</label><span class="spanStar"></span><br>
        <input class="AdjusitBox" name="zip_code" type="text" size="25" placeholder="Enter your zip code"><br>

        <label>Phone Number</label><span class="spanStar"></span><br>
        <input class="AdjusitBox" name="phone_number" type="tel" size="25" placeholder="+966 5*********"><br>

        <button  class="orderButton" type="submit" name="submit">Update Information</button>
    </div>
</form>


</body>

</html>