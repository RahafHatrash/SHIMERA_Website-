<!DOCTYPE html>
<html>

<head>
    <title>HomePage </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<nav class="navbar">
    <ul>
    <li><a href="index.php">Home Page</a></li>
            <li><a href="2product.php">Products</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Contact Us</a></li>
            <li><a href="2login.php"> Login</a></li>
        </ul>
  </nav>
    

    <p> Discover a vast selection of <br> high-performance computer components </p>
    <h3> Shimera Website</h3>

    <div>
        <img src="component/2.png" width="" height="" class="backg1">
        <img src="component/3.png" width="" height="" class="backg2">
        <img src="component/computer.png" width="" height="" class="pcDec">
    </div>

    <img src="component/smaline.png" width="" height="" class="linesmall2">
    <a href="2product.php" class="buttonNext">Shop Now</a>
    <img src="component/smaline.png" width="" height="" class="linesmall">




    <footer class="footer">

        <ul>
            <li>Our Branches : </li> <br>
            <br>
            <div style="text-align:center;">
            <li><a href="https://maps.app.goo.gl/ynVmfsHXWSY17oEw5?g_st=it">Location</a></li><br>
            <li><a href="mailto:r.a.hatrash2001@gmail.com">For contact</a></li>
            </div>
     
            <li> 3789 - Al Fayha Dist. JEDDAH 2902 - 22241 <br> Kingdom of Saudi Arabia</li> <br>
            <li> 8885 - Al Hamra Dist. MAKKAH 2902 - 22241 <br> Kingdom of Saudi Arabia</li><br>
  
        </ul>
    </footer>

</body>

</html>