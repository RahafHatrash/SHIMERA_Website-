<!DOCTYPE html>
<html>

<head>
    <title>HomePage </title>
    <link rel="stylesheet" href="style.css">

    <style>

.mesg{

color: black;
font-family: "Courier New", monospace;
position: relative;
left:40px;
top:100px;
width: 100%;
font-size: 25px;

}
p{
    font-family: "Courier New", monospace;
position: relative;
left:100px;
top:10px;
width: 100%;
font-size: 15px;

}
.siez{
   
    width:30%;
    position: relative;
left:200px;
top:40px;
}
.container1{
    position: relative;
    left:-700px;
top:200px;
}

    </style>
</head>

<body>

<nav class="navbar">

       <div>
        <img src="component/2.png" width="" height="" class="backg1">
        <img src="component/3.png" width="" height="" class="backg2">
 
    </div>
    <h2>Shipping Address</h2>
    <div class="container1">

  

        <h5 class="mesg">Your data has been successfully submitted!</p>

        <p> <a href="Address.php"> Want to see details of the entered address? </a> </p>
        <button class="siez"> <a href="index.php"> Home Page </a> </button>
        
    </div>

</body>
</html>
