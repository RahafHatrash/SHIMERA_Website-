<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Details</title>
    <link rel="stylesheet" href="style.css">
    <style>


ol  li{
  list-style-type: none;
  display:none;
}
a {

  color: black;
  text-align: center;
}

.h31{
    width:80%;
}

.tx3:hover{color:white;}


   </style>
</head>
<body>
<nav class="navbar">
    <ul>
    <li><a href="index.php">Home Page</a></li>
            <li><a href="2product.php">Products</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Contact Us</a></li>
            <li><a href="profile.php">My Profile</a></li>

        </ul>
  </nav>

    <img src="component/2.png" width="" height="" class="backg1">
    <br><br>
    <img src="component/2.png" width="" height="" class="backg1s2"
        style="transform: scaleX(-1); right: 700px; top: 300px;">

    


        <?php


error_reporting(E_ALL);
ini_set('display_errors', 1);


        // Database connection settings
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "PCweb";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve product name from URL parameter
        $productName = $conn->real_escape_string($_GET['productName']);

        // SQL query to fetch all matching products
      
        $stmt = $conn->prepare("SELECT description, price, image_url FROM products WHERE name = ?");
        $stmt->bind_param("s", $productName);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
         
            echo "<div class='item'><img src='" . htmlspecialchars($row['image_url']) . "' alt='Item Image' class='scrolling-image'></div>";
            echo "<div class='content'><div class='content-border'>";
            echo "<h3 class='h31'> " . htmlspecialchars($row['description']) . " <br></h3>";
            echo "<h4> <br> <br>" . number_format($row['price'], 2) . " SAR</h4>";
            ?>
            <table>
                <tr><th>Feature</th><th>Description</th></tr>
                <tr><td>MOTHERBOARD</td><td>ASUS PRIME H510M-A</td></tr>
                <tr><td>CPU</td><td>Intel® Core™ i5-10400 Processor 12M Cache, up to 4.30</td></tr>
                <tr><td>GPU</td><td>Intel® UHD Graphics 630</td></tr>
                <tr><td>RAM</td><td>ADATA XPG 8GB 1*8GB SPECTRIX D35G RGB DDR4 3200MHZ WHITE</td></tr>
                <tr><td>POWER SUPPLY</td><td>FSP 550W 80</td></tr>
                <tr><td>HARD DISK</td><td>Lexar NM610 500GB M.2 2280 NVME up to 2100 MB/s read and 1600 MB/s write</td></tr>
                <tr><td>CASE</td><td>PCD VANGUARD WHITE</td></tr>
            </table>

            <div>
                <select>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    </select>
                <button class="tx3"><a class='tx3' href="OrderDetailsPage.php">Buy Now</a></button>
                <button><a href="OrderDetailsPage.php">Add to cart</a></button>
            </div>

          
            <ol>
                <li><img src="image1.jpg" alt="Image 1 Warranty" class="img2"></li>
                <li><img src="image2.jpg" alt="Image 2 Windows" class="img2"></li>
                <li><img src="image3.jpg" alt="Image 3 Shipping" class="img2"></li>
                <li><img src="image4.jpg" alt="Image 4 Installation" class="img2"></li>
            </ol>

            <span class="ReviewFont">Reviews</span>
            <div class="comment-box">
                <textarea placeholder="Write your comment here"></textarea>
            </div>
            <img src="review1.png" alt="Review Image 1" class="review-images"></li>
            <img src="review2.png" alt="Review Image 2" class="review-images"></li>
            <?php
            echo "</div></div>"; // Close content and content-border divs
            echo "</div>";
        } else {
            echo "<p>No product found matching your search.</p>";
        }

        // Close connection
        $stmt->close();
        $conn->close();
        ?>
    </div>
</body>
</html>
